<?php return array('dependencies' => array('react-jsx-runtime', 'wp-blocks', 'wp-dom-ready', 'wp-element', 'wp-server-side-render'), 'version' => 'e6abfc0da653d80b01fe');
