<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'df1fed0bd0148fe6a465');
